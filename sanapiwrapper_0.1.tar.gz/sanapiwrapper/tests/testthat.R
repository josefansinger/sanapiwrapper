library(testthat)
library(sanapiwrapper)

test_check("sanapiwrapper")
