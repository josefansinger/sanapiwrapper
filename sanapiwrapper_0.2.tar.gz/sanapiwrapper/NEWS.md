# Version 0.2 (2020-05-15)

* make use of access restrictions (which depend on API key) to determine the correct time windows for query


# Version 0.1 (2020-05-12)

* first commit